#include <vector>
#include <iostream>
#include <algorithm>
#include <cstdint>
#include <cassert>

#include "preprocessedinstance.hpp"
#include "global.hpp"
#include "utility.hpp"

#define F first
#define S second

using namespace std;
namespace maxPreprocessor {

}