tempdir

The documentation and license can be found in docs as reStructuredText.
Enjoy...
